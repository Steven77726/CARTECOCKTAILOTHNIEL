# Winess Signature - Web App iPad

Dossier prêt pour GitHub Pages.

## Upload GitHub

1. Créer un nouveau repository GitHub.
2. Envoyer tout le contenu de ce dossier à la racine du repository.
3. Dans GitHub: Settings > Pages.
4. Source: Deploy from a branch.
5. Branch: main / root.

Le fichier principal est `index.html`.

Ne pas déplacer le dossier `assets/winess`, car les images sont appelées avec ce chemin.
