const cocktails = [
  {
    id: "passion-martini",
    name: "Passion Martini",
    image: "assets/winess/passion-martini.png",
    ingredients: ["Vodka", "Purée de passion", "Citron vert", "Vanille"],
    photoScale: 1.18,
    photoPosition: "50% 48%",
    description: "Un cocktail fruité et raffiné mêlant la douceur de la passion à la fraîcheur du citron vert."
  },
  {
    id: "raspberry-passion",
    name: "Raspberry Passion",
    image: "assets/winess/raspberry-passion.png",
    ingredients: ["Vodka", "Purée de passion", "Framboise", "Citron vert"],
    photoScale: 1.17,
    photoPosition: "50% 48%",
    description: "Une création élégante où la framboise apporte une note vive à la rondeur exotique de la passion."
  },
  {
    id: "gin-basil-smash",
    name: "Gin Basil Smash",
    image: "assets/winess/gin-basil-smash.png",
    ingredients: ["Gin", "Basilic frais", "Citron", "Sirop de sucre"],
    photoScale: 1.1,
    photoPosition: "50% 50%",
    description: "Un cocktail frais et aromatique, entre basilic délicat, gin premium et équilibre citronné."
  },
  {
    id: "moscow-mule",
    name: "Moscow Mule",
    image: "assets/winess/moscow-mule.png",
    ingredients: ["Vodka", "Citron vert", "Ginger Beer"],
    photoScale: 1.1,
    photoPosition: "50% 50%",
    description: "Une signature pétillante et précise, relevée par le ginger beer et la fraîcheur du citron vert."
  }
];

const stage = document.querySelector("[data-stage]");
const grid = document.querySelector("#cocktailGrid");
const logoButton = document.querySelector("#logoButton");
const overlay = document.querySelector("#overlay");
const brandPanel = document.querySelector("#brandPanel");
const detailPanel = document.querySelector("#detailPanel");
const detailPhoto = document.querySelector("#detailPhoto");
const detailTitle = document.querySelector("#detailTitle");
const detailDescription = document.querySelector("#detailDescription");
const detailIngredients = document.querySelector("#detailIngredients");

let activeCard = null;
let activePanel = null;
let isAnimating = false;

renderCocktails();

logoButton.addEventListener("click", () => {
  if (activePanel === "brand") {
    closePanel();
    return;
  }

  logoButton.classList.add("is-opening");
  window.setTimeout(() => logoButton.classList.remove("is-opening"), 640);
  window.setTimeout(() => openPanel("brand"), 280);
});

overlay.addEventListener("click", (event) => {
  if (event.target === overlay) {
    closePanel();
  }
});

brandPanel.addEventListener("click", (event) => event.stopPropagation());
detailPanel.addEventListener("click", closePanel);

window.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && activePanel) {
    closePanel();
  }
});

function renderCocktails() {
  grid.innerHTML = cocktails.map(renderCard).join("");

  grid.querySelectorAll(".cocktail-card").forEach((card) => {
    const cocktail = cocktails.find((item) => item.id === card.dataset.id);

    card.addEventListener("pointermove", (event) => updateTilt(event, card));
    card.addEventListener("pointerleave", () => resetTilt(card));
    card.addEventListener("click", () => {
      if (activePanel === "detail" && activeCard === card) {
        closePanel();
        return;
      }

      openCocktail(cocktail, card);
    });
  });
}

function renderCard(cocktail) {
  return `
    <button class="cocktail-card" type="button" data-id="${cocktail.id}" aria-label="${cocktail.name}" style="--photo-scale: ${cocktail.photoScale}; --photo-position: ${cocktail.photoPosition};">
      <span class="card-photo">
        <img src="${cocktail.image}" alt="${cocktail.name}" draggable="false">
      </span>
      <h2>${cocktail.name}</h2>
      <ul class="ingredient-list" aria-label="Ingrédients">
        ${cocktail.ingredients.map((ingredient) => `<li>${ingredient}</li>`).join("")}
      </ul>
    </button>
  `;
}

function updateTilt(event, card) {
  if (activePanel) {
    return;
  }

  const rect = card.getBoundingClientRect();
  const x = (event.clientX - rect.left) / rect.width - 0.5;
  const y = (event.clientY - rect.top) / rect.height - 0.5;

  card.style.setProperty("--tilt-x", `${(-y * 4).toFixed(2)}deg`);
  card.style.setProperty("--tilt-y", `${(x * 4).toFixed(2)}deg`);
}

function resetTilt(card) {
  card.style.setProperty("--tilt-x", "0deg");
  card.style.setProperty("--tilt-y", "0deg");
}

function openCocktail(cocktail, card) {
  if (isAnimating || !cocktail || !card) {
    return;
  }

  isAnimating = true;
  activeCard = card;
  fillDetail(cocktail);
  grid.querySelectorAll(".cocktail-card").forEach((item) => item.classList.remove("is-active", "is-opening"));
  card.classList.add("is-active", "is-opening");

  window.setTimeout(() => {
    openPanel("detail");
    isAnimating = false;
  }, 300);

  window.setTimeout(() => {
    card.classList.remove("is-opening");
  }, 720);
}

function fillDetail(cocktail) {
  detailPhoto.src = cocktail.image;
  detailPhoto.alt = cocktail.name;
  detailTitle.textContent = cocktail.name;
  detailDescription.textContent = cocktail.description;
  detailIngredients.innerHTML = cocktail.ingredients.map((ingredient) => `<span>${ingredient}</span>`).join("");
}

function openPanel(panelName) {
  activePanel = panelName;
  overlay.classList.add("is-open");
  overlay.setAttribute("aria-hidden", "false");
  stage.classList.add("is-blurred");

  brandPanel.classList.toggle("is-visible", panelName === "brand");
  detailPanel.classList.toggle("is-visible", panelName === "detail");
}

function closePanel() {
  overlay.classList.remove("is-open");
  overlay.setAttribute("aria-hidden", "true");
  stage.classList.remove("is-blurred");
  activePanel = null;

  window.setTimeout(() => {
    brandPanel.classList.remove("is-visible");
    detailPanel.classList.remove("is-visible");
    if (activeCard) {
      activeCard.classList.remove("is-active", "is-opening");
      activeCard = null;
    }
  }, 260);
}
